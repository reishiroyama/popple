using UnityEngine.Advertisements;
using UnityEngine;
using UnityEngine.Events;


public class UnityAds421 : MonoBehaviour, IUnityAdsInitializationListener, IUnityAdsLoadListener, IUnityAdsShowListener
{

    public string GAME_ID = "4805647"; //replace with your gameID from dashboard. note: will be different for each platform.

    public string BANNER_PLACEMENT = "Banner_iOS";
    public string INTERSTITIAL_PLACEMENT = "Interstitial_iOS";
    public string REWARDED_VIDEO_PLACEMENT = "Rewarded_iOS";
    
    [SerializeField] private BannerPosition bannerPosition = BannerPosition.BOTTOM_CENTER;

    public bool testMode = true;
    private bool showBanner = false;

    //utility wrappers for debuglog
    public delegate void DebugEvent(string msg);
    public static event DebugEvent OnDebugLog;

    //Macro
    public UnityEvent Trigger_AdsEventName;


    public string Return_AdsShowingId = "";
    public string Return_AdsEventName = "";
    public string Return_AdsError = "";
    //---------------

    public void Initialize()
    {
        if (Advertisement.isSupported)
        {
            //DebugLog(Application.platform + " supported by Advertisement");
        }
        Advertisement.Initialize(GAME_ID, testMode, this);
    }

    public void ToggleBanner()
    {
        showBanner = !showBanner;

        if (showBanner)
        {
            Advertisement.Banner.SetPosition(bannerPosition);
            Advertisement.Banner.Show(BANNER_PLACEMENT);
        }
        else
        {
            Advertisement.Banner.Hide(false);
        }
    }

    public void LoadRewardedAd()
    {
        Advertisement.Load(REWARDED_VIDEO_PLACEMENT, this);
    }

    public void ShowRewardedAd()
    {
        Advertisement.Show(REWARDED_VIDEO_PLACEMENT, this);
    }

    public void LoadNonRewardedAd()
    {
        Advertisement.Load(INTERSTITIAL_PLACEMENT, this);
    }

    public void ShowNonRewardedAd()
    {
        Advertisement.Show(INTERSTITIAL_PLACEMENT, this);
    }

   
    public void OnInitializationComplete()
    {

        Return_AdsEventName = "Initial";
        Trigger_AdsEventName.Invoke();
    }


    public void OnInitializationFailed(UnityAdsInitializationError error, string message)
    {
        DebugLog($"Init Failed: [{error}]: {message}");
    }

    public void OnUnityAdsAdLoaded(string placementId)
    {
        //DebugLog($"Load Success: {placementId}");
        Return_AdsShowingId = placementId;
        Return_AdsEventName = "AdLoaded";
        Trigger_AdsEventName.Invoke();
    }

    public void OnUnityAdsFailedToLoad(string placementId, UnityAdsLoadError error, string message)
    {
        //DebugLog($"Load Failed: [{error}:{placementId}] {message}");

        Return_AdsShowingId = placementId;

        if (error == UnityAdsLoadError.INITIALIZE_FAILED)
        {

            Return_AdsError = "INITIALIZE_FAILED";
        }
        if (error == UnityAdsLoadError.INTERNAL_ERROR)
        {

            Return_AdsError = "INTERNAL_ERROR";
        }
        if (error == UnityAdsLoadError.INVALID_ARGUMENT)
        {

            Return_AdsError = "INVALID_ARGUMENT";
        }
        if (error == UnityAdsLoadError.NO_FILL)
        {

            Return_AdsError = "NO_FILL";
        }
        if (error == UnityAdsLoadError.TIMEOUT)
        {

            Return_AdsError = "TIMEOUT";
        }
        if (error == UnityAdsLoadError.UNKNOWN)
        {

            Return_AdsError = "UNKNOWN";
        }

        Return_AdsEventName = "AdsFailedToLoad";
        Trigger_AdsEventName.Invoke();
    }

    public void OnUnityAdsShowFailure(string placementId, UnityAdsShowError error, string message)
    {
        Return_AdsShowingId = placementId;

        //DebugLog($"OnUnityAdsShowFailure: [{error}]: {message}");
        if (error == UnityAdsShowError.NOT_INITIALIZED)
        {

            Return_AdsError = "NOT_INITIALIZED";
        }
        if (error == UnityAdsShowError.ALREADY_SHOWING)
        {

            Return_AdsError = "ALREADY_SHOWING";
        }
        if (error == UnityAdsShowError.INTERNAL_ERROR)
        {

            Return_AdsError = "INTERNAL_ERROR";
        }
        if (error == UnityAdsShowError.INVALID_ARGUMENT)
        {

            Return_AdsError = "INVALID_ARGUMENT";
        }
        
        if (error == UnityAdsShowError.NOT_READY)
        {

            Return_AdsError = "NOT_READY";
        }
        if (error == UnityAdsShowError.NO_CONNECTION)
        {

            Return_AdsError = "NO_CONNECTION";
        }
        if (error == UnityAdsShowError.UNKNOWN)
        {

            Return_AdsError = "UNKNOWN";
        }
        if (error == UnityAdsShowError.VIDEO_PLAYER_ERROR)
        {

            Return_AdsError = "VIDEO_PLAYER_ERROR";
        }
        Return_AdsEventName = "AdsShowFailure";
        Trigger_AdsEventName.Invoke();
    }

    public void OnUnityAdsShowStart(string placementId)
    {
        Return_AdsShowingId = placementId;

        Return_AdsEventName = "AdsStart";
        Trigger_AdsEventName.Invoke();
        
    }

    public void OnUnityAdsShowClick(string placementId)
    {
        Return_AdsShowingId = placementId;

        Return_AdsEventName = "AdsClicked";
        Trigger_AdsEventName.Invoke();
    }

    public void OnUnityAdsShowComplete(string placementId, UnityAdsShowCompletionState showCompletionState)
    {
        Return_AdsShowingId = placementId;

        
        

        if (showCompletionState == UnityAdsShowCompletionState.COMPLETED)
        {
            Return_AdsEventName = "AdsShowCOMPLETED";
        }
        if (showCompletionState == UnityAdsShowCompletionState.SKIPPED)
        {
            Return_AdsEventName = "AdsShowSKIPPED";
        }
        if (showCompletionState == UnityAdsShowCompletionState.UNKNOWN)
        {
            Return_AdsEventName = "AdsShowUNKNOWN";
        }

        Trigger_AdsEventName.Invoke();
    }
   

    public void OnGameIDFieldChanged(string newInput)
    {
        GAME_ID = newInput;
    }

    public void ToggleTestMode(bool isOn)
    {
        testMode = isOn;
    }

    //wrapper around debug.log to allow broadcasting log strings to the UI
    void DebugLog(string msg)
    {
        OnDebugLog?.Invoke(msg);
        Debug.Log(msg);
    }
}
